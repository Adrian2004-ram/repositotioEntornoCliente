
// Solicitar al usuario los datos necesarios
let numSala = prompt("Ingrese el número de sala: ");
let numFila = prompt("Ingrese el número de fila: ");
let numAsiento = prompt("Ingrese el número de asiento: ");

